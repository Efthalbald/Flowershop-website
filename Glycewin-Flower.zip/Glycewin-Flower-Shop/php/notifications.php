<?php
/** Email and order-history helpers. Configure a working PHP mail transport before production use. */
function glycewinSendEmail(string $to, string $subject, string $message): bool {
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) return false;
    $from = getenv('GLYCEWIN_MAIL_FROM') ?: 'no-reply@glycewin.local';
    $headers = "From: Glycewin Handmade Flower Shop <{$from}>\r\n";
    $headers .= "MIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\n";
    return @mail($to, '=?UTF-8?B?'.base64_encode($subject).'?=', $message, $headers);
}
function glycewinNotifyAdmin(string $subject, string $message): bool {
    $to = getenv('GLYCEWIN_ADMIN_EMAIL') ?: '';
    return $to !== '' ? glycewinSendEmail($to, $subject, $message) : false;
}
function glycewinTableExists(mysqli $conn, string $table): bool {
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $table)) return false;
    $safeTable = mysqli_real_escape_string($conn, $table);
    $result = mysqli_query($conn, "SHOW TABLES LIKE '{$safeTable}'");
    return $result && mysqli_num_rows($result) > 0;
}
function glycewinRecordTimeline(mysqli $conn, string $type, int $id, string $status, string $note = ''): void {
    if ($id < 1 || !in_array($type, ['custom','bulk','product'], true) || !glycewinTableExists($conn, 'order_status_history')) return;
    $stmt = mysqli_prepare($conn, 'INSERT INTO order_status_history (order_type, order_id, status, note, created_at) VALUES (?, ?, ?, ?, NOW())');
    if ($stmt) { mysqli_stmt_bind_param($stmt, 'siss', $type, $id, $status, $note); mysqli_stmt_execute($stmt); mysqli_stmt_close($stmt); }
}
function glycewinGetOrCreateCustomer(mysqli $conn, string $name, string $email, string $phone, string $address): int {
    $stmt = mysqli_prepare($conn, 'SELECT customer_id FROM customers WHERE email = ? LIMIT 1');
    if (!$stmt) return 0;
    mysqli_stmt_bind_param($stmt, 's', $email); mysqli_stmt_execute($stmt); $result = mysqli_stmt_get_result($stmt);
    $row = $result ? mysqli_fetch_assoc($result) : null; mysqli_stmt_close($stmt);
    if ($row) {
        $id = (int)$row['customer_id'];
        $update = $address !== ''
            ? mysqli_prepare($conn, 'UPDATE customers SET full_name=?, phone=?, address=? WHERE customer_id=?')
            : mysqli_prepare($conn, 'UPDATE customers SET full_name=?, phone=? WHERE customer_id=?');
        if ($update) {
            if ($address !== '') mysqli_stmt_bind_param($update, 'sssi', $name, $phone, $address, $id);
            else mysqli_stmt_bind_param($update, 'ssi', $name, $phone, $id);
            mysqli_stmt_execute($update); mysqli_stmt_close($update);
        }
        return $id;
    }
    $insert = mysqli_prepare($conn, 'INSERT INTO customers (full_name,email,phone,address) VALUES (?,?,?,?)');
    if (!$insert) return 0;
    mysqli_stmt_bind_param($insert, 'ssss', $name, $email, $phone, $address);
    $ok = mysqli_stmt_execute($insert); $id = $ok ? (int)mysqli_insert_id($conn) : 0; mysqli_stmt_close($insert); return $id;
}
function glycewinEscape($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
