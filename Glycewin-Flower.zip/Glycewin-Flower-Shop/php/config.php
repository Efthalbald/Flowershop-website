<?php
// Central database connection for the Glycewin Handmade Flower Shop.
mysqli_report(MYSQLI_REPORT_OFF);
$host = getenv('GLYCEWIN_DB_HOST') ?: 'localhost';
$user = getenv('GLYCEWIN_DB_USER') ?: 'root';
$password = getenv('GLYCEWIN_DB_PASSWORD') ?: '';
$database = getenv('GLYCEWIN_DB_NAME') ?: 'glycewin_flower_shop';
$conn = mysqli_connect($host, $user, $password, $database);
if (!$conn) {
    http_response_code(500);
    error_log('Glycewin database connection failed: ' . mysqli_connect_error());
    exit('The shop is temporarily unavailable because the database connection failed. Check php/config.php and your XAMPP MySQL service.');
}
mysqli_set_charset($conn, 'utf8mb4');
