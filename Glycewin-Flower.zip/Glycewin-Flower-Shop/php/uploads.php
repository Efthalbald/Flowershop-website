<?php
/** Validate and store an image upload; returns a safe filename or null on failure. */
function glycewinStoreImage(array $upload, string $absoluteDirectory, string $prefix = 'img_'): ?string {
    if (!isset($upload['error']) || $upload['error'] !== UPLOAD_ERR_OK || empty($upload['tmp_name'])) return null;
    if (!is_uploaded_file($upload['tmp_name']) || (int)$upload['size'] > 5 * 1024 * 1024) return null;
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($upload['tmp_name']);
    $extensions = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    if (!isset($extensions[$mime])) return null;
    if (!is_dir($absoluteDirectory) && !mkdir($absoluteDirectory, 0755, true) && !is_dir($absoluteDirectory)) return null;
    $filename = $prefix . bin2hex(random_bytes(10)) . '.' . $extensions[$mime];
    return move_uploaded_file($upload['tmp_name'], rtrim($absoluteDirectory, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $filename) ? $filename : null;
}
