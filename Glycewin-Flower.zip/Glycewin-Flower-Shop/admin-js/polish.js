/* Glycewin – admin interaction polish. Progressive enhancement only. */
(function () {
  'use strict';
  var doc = document;
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function $(s, c) { return (c || doc).querySelector(s); }
  function $$(s, c) { return Array.prototype.slice.call((c || doc).querySelectorAll(s)); }
  function onReady(fn) { if (doc.readyState !== 'loading') fn(); else doc.addEventListener('DOMContentLoaded', fn); }

  onReady(function () {
    /* ---- Dashboard numbers count up ---- */
    if (!reduce) {
      $$('.dashboard-cards .card h2').forEach(function (el) {
        var target = parseInt(el.textContent.replace(/[^\d]/g, ''), 10);
        if (!isFinite(target) || target < 1 || target > 100000 || !/^\s*\d+\s*$/.test(el.textContent)) return;
        var start = null, dur = 700 + Math.min(target, 60) * 6;
        function step(t) {
          if (start === null) start = t;
          var p = Math.min((t - start) / dur, 1), e = 1 - Math.pow(1 - p, 3);
          el.textContent = Math.round(target * e);
          if (p < 1) requestAnimationFrame(step); else el.textContent = target;
        }
        el.textContent = '0';
        requestAnimationFrame(step);
      });
    }

    /* ---- Staggered table row entrance (first 20 rows) ---- */
    if (!reduce) {
      $$('.admin-table tbody tr').slice(0, 20).forEach(function (tr, i) {
        tr.style.setProperty('--gw-i', i); tr.classList.add('gw-row');
      });
    }

    /* ---- Success alerts fade away on their own (errors stay) ---- */
    $$('.alert.success, .alert-success, .success-message').forEach(function (a) {
      setTimeout(function () {
        a.classList.add('gw-hide');
        setTimeout(function () { a.style.display = 'none'; }, 450);
      }, 5000);
    });

    /* ---- Submit feedback: spinner + double-submit protection ---- */
    $$('form').forEach(function (form) {
      form.addEventListener('submit', function (e) { if (form.__gwBusy) e.preventDefault(); }, true);
      form.addEventListener('submit', function (ev) {
        setTimeout(function () {
          if (form.__gwBusy || ev.defaultPrevented) return;
          var btn = $('button[type="submit"], input[type="submit"], button:not([type])', form);
          if (!btn) return;
          form.__gwBusy = true; btn.classList.add('is-loading');
          setTimeout(function () { form.__gwBusy = false; btn.classList.remove('is-loading'); }, 6000);
        }, 0);
      });
    });

    /* ---- Keep the active sidebar item in view on small screens ---- */
    var active = $('.sidebar-menu li.active');
    if (active && active.scrollIntoView && window.innerWidth <= 992) {
      active.scrollIntoView({ block: 'nearest', inline: 'center' });
    }
  });
})();

/* ======================================================================
   Feature polish: inquiry replies, payment-proof review, email notices
   ====================================================================== */
(function () {
  'use strict';
  var doc = document;
  function $(s, c) { return (c || doc).querySelector(s); }
  function $$(s, c) { return Array.prototype.slice.call((c || doc).querySelectorAll(s)); }
  function esc(t) { return String(t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  /* Client-side search + status filter above a table */
  function addFilter(table, statusOf, statuses, placeholder) {
    var card = table.closest('.table-card'); if (!card) return;
    var rows = $$('tbody tr', table).filter(function (r) { return !$('.empty-state', r); });
    if (rows.length < 2) return;
    var bar = doc.createElement('div'); bar.className = 'gw-filter';
    bar.innerHTML = '<input type="search" placeholder="' + esc(placeholder) + '" aria-label="Search"><div class="gw-chips"></div><span class="gw-count"></span>';
    var scroll = $('.table-scroll', card) || table; scroll.parentNode.insertBefore(bar, scroll);
    var q = $('input', bar), chips = $('.gw-chips', bar), count = $('.gw-count', bar), cur = 'All';
    ['All'].concat(statuses).forEach(function (s) {
      var n = s === 'All' ? rows.length : rows.filter(function (r) { return statusOf(r) === s; }).length;
      var b = doc.createElement('button'); b.type = 'button'; b.className = 'gw-chip-btn' + (s === 'All' ? ' on' : '');
      b.textContent = s + ' (' + n + ')'; b.dataset.s = s; chips.appendChild(b);
    });
    function apply() {
      var t = q.value.trim().toLowerCase(), shown = 0;
      rows.forEach(function (r) {
        var ok = (cur === 'All' || statusOf(r) === cur) && (!t || r.textContent.toLowerCase().indexOf(t) > -1);
        r.style.display = ok ? '' : 'none'; if (ok) shown++;
      });
      count.textContent = shown + ' of ' + rows.length + ' shown';
    }
    chips.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      cur = b.dataset.s; $$('button', chips).forEach(function (x) { x.classList.toggle('on', x === b); }); apply();
    });
    q.addEventListener('input', apply); apply();
  }

  function ready() {
    /* ---------- Inquiries ---------- */
    if ($('h1') && /Inquiries/i.test($('h1').textContent) && $('.admin-table')) {
      var table = $('.admin-table');
      addFilter(table, function (r) { var s = $('select[name="status"]', r); return s ? s.value : ''; },
        ['New', 'In Progress', 'Responded', 'Closed'], 'Search name, email or message…');
      $$('.admin-table tbody tr').forEach(function (r) {
        var f = $('form.admin-form', r); if (!f) return;
        var ta = $('textarea', f), sel = $('select[name="status"]', f), btn = $('button[name="save_response"]', f);
        var link = $('a[href^="mailto:"]', r), to = link ? link.textContent.trim() : '';
        var hint = doc.createElement('div'); hint.className = 'gw-mail-hint'; f.appendChild(hint);
        var count = doc.createElement('small'); count.className = 'gw-count-s'; ta.parentNode.appendChild(count);
        var upd = function () {
          var has = ta.value.trim() !== '';
          hint.innerHTML = has ? '✉ Saving will email this reply to <strong>' + esc(to) + '</strong>.' : 'ⓘ No email is sent while the response is empty.';
          hint.classList.toggle('on', has); count.textContent = ta.value.length + ' characters';
          sel.className = 'gw-st gw-st-' + sel.value.toLowerCase().replace(/\s+/g, '-');
        };
        ta.addEventListener('input', upd); sel.addEventListener('change', upd); upd();
        f.addEventListener('submit', function (e) {
          if (ta.value.trim() !== '' && !window.confirm('Send this reply by email to ' + to + '?')) { e.preventDefault(); f.__gwBusy = false; btn && btn.classList.remove('is-loading'); }
        }, true);
      });
    }

    /* ---------- Payment proofs ---------- */
    if ($('h1') && /Payment/i.test($('h1').textContent) && $('.admin-table')) {
      var pt = $('.admin-table');
      var cur = function (r) { var s = $('strong', r.cells[r.cells.length - 1]); return s ? s.textContent.replace(/^Current:\s*/i, '').trim() : ''; };
      var seen = {}; $$('tbody tr', pt).forEach(function (r) { if (!$('.empty-state', r)) seen[cur(r)] = 1; });
      var order = ['Pending', 'Verified', 'Rejected']; Object.keys(seen).forEach(function (k) { if (order.indexOf(k) < 0 && k) order.push(k); });
      addFilter(pt, cur, order, 'Search order, payer, email or reference…');
      $$('.admin-table tbody tr').forEach(function (r) {
        var f = $('form.status-form', r); if (!f) return;
        var strong = $('strong', r.cells[r.cells.length - 1]);
        if (strong) strong.className = 'gw-pay gw-pay-' + cur(r).toLowerCase();
        var sel = $('select[name="verification_status"]', f), mail = $('a[href^="mailto:"]', r);
        var small = $('small', r.cells[2]), to = small ? small.textContent.trim() : '';
        var hint = doc.createElement('div'); hint.className = 'gw-mail-hint on'; hint.innerHTML = '✉ The payer (<strong>' + esc(to) + '</strong>) is emailed the result.'; f.appendChild(hint);
        f.addEventListener('submit', function (e) {
          if (!window.confirm('Mark this proof as ' + sel.value + ' and email ' + to + '?')) { e.preventDefault(); f.__gwBusy = false; $$('.is-loading', f).forEach(function (b) { b.classList.remove('is-loading'); }); }
        }, true);
      });
    }
  }
  if (doc.readyState !== 'loading') ready(); else doc.addEventListener('DOMContentLoaded', ready);
})();
