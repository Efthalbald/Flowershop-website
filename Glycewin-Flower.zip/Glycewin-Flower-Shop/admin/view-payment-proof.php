<?php
session_start();if(!isset($_SESSION['admin_id'])){http_response_code(403);exit('Forbidden');}
require_once __DIR__.'/../php/config.php';
$file=basename((string)($_GET['file']??''));if($file===''||!preg_match('/^proof_[a-f0-9]+\.(jpg|png|webp|pdf)$/i',$file)){http_response_code(400);exit('Invalid file');}
$path=realpath(__DIR__.'/../uploads/payment-proofs/'.$file);$base=realpath(__DIR__.'/../uploads/payment-proofs');if(!$path||!$base||strpos($path,$base.DIRECTORY_SEPARATOR)!==0||!is_file($path)){http_response_code(404);exit('File not found');}
$ext=strtolower(pathinfo($path,PATHINFO_EXTENSION));$mime=['jpg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','pdf'=>'application/pdf'][$ext]??'application/octet-stream';header('Content-Type: '.$mime);header('Content-Length: '.filesize($path));header('X-Content-Type-Options: nosniff');header('Content-Disposition: inline; filename="'.basename($path).'"');readfile($path);
