<?php
session_start();if(!isset($_SESSION['admin_id'])){header('Location: login.php');exit;}
require_once __DIR__.'/../php/config.php';require_once __DIR__.'/../php/uploads.php';
$id=(int)($_GET['id']??$_POST['id']??0);$error='';
$stmt=mysqli_prepare($conn,'SELECT * FROM products WHERE product_id=? LIMIT 1');mysqli_stmt_bind_param($stmt,'i',$id);mysqli_stmt_execute($stmt);$res=mysqli_stmt_get_result($stmt);$product=$res?mysqli_fetch_assoc($res):null;mysqli_stmt_close($stmt);
if(!$product){header('Location: products.php');exit;}
if(isset($_POST['update'])){
 $name=trim((string)($_POST['product_name']??''));$category=trim((string)($_POST['category']??''));$description=trim((string)($_POST['description']??''));$price=filter_var($_POST['price']??null,FILTER_VALIDATE_FLOAT);$stock=filter_var($_POST['stock']??null,FILTER_VALIDATE_INT);$status=(string)($_POST['status']??'');$image=$product['image'];$newImage=null;
 if($name===''||$category===''||$description===''||$price===false||$price<0||$stock===false||$stock<0||!in_array($status,['Available','Unavailable'],true))$error='Check the product name, category, description, price, stock, and availability.';
 elseif(isset($_FILES['image'])&&($_FILES['image']['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_NO_FILE){$newImage=glycewinStoreImage($_FILES['image'],__DIR__.'/../images/products/','product_');if(!$newImage)$error='New image must be a valid JPG, PNG, or WEBP file up to 5 MB.';else$image=$newImage;}
 if($error===''){$upd=mysqli_prepare($conn,'UPDATE products SET product_name=?,category=?,description=?,price=?,stock=?,image=?,status=? WHERE product_id=?');if($upd){mysqli_stmt_bind_param($upd,'sssdissi',$name,$category,$description,$price,$stock,$image,$status,$id);if(mysqli_stmt_execute($upd)){if($newImage&&!empty($product['image'])){$oldPath=realpath(__DIR__.'/../images/products/'.basename($product['image']));$base=realpath(__DIR__.'/../images/products');if($oldPath&&$base&&strpos($oldPath,$base.DIRECTORY_SEPARATOR)===0&&is_file($oldPath))@unlink($oldPath);}header('Location: products.php');exit;}else{$error='Could not update product.';if($newImage)@unlink(__DIR__.'/../images/products/'.$newImage);}mysqli_stmt_close($upd);}else{$error='Could not prepare product update.';if($newImage)@unlink(__DIR__.'/../images/products/'.$newImage);}}
 $product=array_merge($product,['product_name'=>$name,'category'=>$category,'description'=>$description,'price'=>$_POST['price']??$product['price'],'stock'=>$_POST['stock']??$product['stock'],'status'=>$status,'image'=>$image]);
}
?>


<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Edit Product</title>

<link rel="stylesheet"
href="../admin-css/admin.css">
<link rel="stylesheet" href="../admin-css/upgrade.css">

<link rel="stylesheet" href="../admin-css/polish.css">
</head>

<body>

<div class="page-header">

<h1>

Edit Product

</h1>

<a href="products.php" class="btn">

← Back

</a>

</div>

<?php if($error!==''): ?><div class="error"><?php echo htmlspecialchars($error,ENT_QUOTES,'UTF-8'); ?></div><?php endif; ?>
<form

method="POST"

enctype="multipart/form-data"

class="admin-form">

<label>

Product Name

</label>

<input

type="text"

name="product_name"

value="<?php echo htmlspecialchars($product['product_name']); ?>"

required>

<label>

Category

</label>

<select name="category">

<option value="Bouquet"
<?php if($product['category']=="Bouquet") echo "selected"; ?>>

Bouquet

</option>

<option value="Flower Box"
<?php if($product['category']=="Flower Box") echo "selected"; ?>>

Flower Box

</option>

<option value="Money Bouquet"
<?php if($product['category']=="Money Bouquet") echo "selected"; ?>>

Money Bouquet

</option>

<option value="Chocolate Bouquet"
<?php if($product['category']=="Chocolate Bouquet") echo "selected"; ?>>

Chocolate Bouquet

</option>

<option value="Customized"
<?php if($product['category']=="Customized") echo "selected"; ?>>

Customized

</option>

</select>

<label>

Description

</label>

<textarea

name="description"

rows="5"

required><?php echo htmlspecialchars($product['description']); ?></textarea>

<label>

Price (₱)

</label>

<input

type="number"

name="price"

step="0.01"

min="0"

value="<?php echo $product['price']; ?>"

required>

<label>

Stock

</label>

<input

type="number"

name="stock"

min="0"

value="<?php echo $product['stock']; ?>"

required>

<label>

Status

</label>

<select

name="status">

<option

value="Available"

<?php if($product['status']=="Available") echo "selected"; ?>>

Available

</option>

<option

value="Unavailable"

<?php if($product['status']=="Unavailable") echo "selected"; ?>>

Unavailable

</option>

</select>

<label>

Current Product Image

</label>

<br><br>

<img

src="../images/products/<?php echo htmlspecialchars($product['image']); ?>"

width="180"

style="border-radius:10px; margin-bottom:20px;">

<label>

Upload New Image (Optional)

</label>

<input

type="file"

name="image"

accept="image/*">

<br><br>

<button

type="submit"

name="update"

class="btn">

Update Product

</button>

<a

href="products.php"

class="btn">

Cancel

</a>

</form>

<script src="../admin-js/polish.js" defer></script>
</body>

</html>