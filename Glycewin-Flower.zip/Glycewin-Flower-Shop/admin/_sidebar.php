<?php $activePage = $activePage ?? ''; ?>
<aside class="sidebar">
  <div class="sidebar-logo"><img src="../images/logo.png" alt="Glycewin logo"><h2>GLYCEWIN</h2><p>Admin Panel</p></div>
  <ul class="sidebar-menu">
    <li class="<?php echo $activePage === 'dashboard' ? 'active' : ''; ?>"><a href="dashboard.php">🏠 Dashboard</a></li>
    <li class="<?php echo $activePage === 'products' ? 'active' : ''; ?>"><a href="products.php">🌸 Products</a></li>
    <li class="<?php echo $activePage === 'custom' ? 'active' : ''; ?>"><a href="custom-orders.php">🎨 Custom Orders</a></li>
    <li class="<?php echo $activePage === 'bulk' ? 'active' : ''; ?>"><a href="bulk-orders.php">🏢 Bulk Orders</a></li>
    <li class="<?php echo $activePage === 'product-orders' ? 'active' : ''; ?>"><a href="product-orders.php">🛍 Product Orders</a></li>
    <li class="<?php echo $activePage === 'inquiries' ? 'active' : ''; ?>"><a href="inquiries.php">✉️ Inquiries</a></li>
    <li class="<?php echo $activePage === 'payments' ? 'active' : ''; ?>"><a href="payment-verification.php">💳 Payment Proofs</a></li>
    <li class="<?php echo $activePage === 'pricing' ? 'active' : ''; ?>"><a href="pricing.php">💐 Custom Pricing</a></li>
    <li><a href="logout.php" class="btn">↪ Logout</a></li>
  </ul>
</aside>
