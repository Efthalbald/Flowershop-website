<?php
require_once __DIR__ . '/php/config.php';
require_once __DIR__ . '/php/notifications.php';
$productId = filter_input(INPUT_GET, 'product_id', FILTER_VALIDATE_INT) ?: filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
if (!$productId) { header('Location: products.php'); exit; }
$stmt = mysqli_prepare($conn, "SELECT * FROM products WHERE product_id=? AND status='Available' AND stock>0 LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $productId); mysqli_stmt_execute($stmt); $res = mysqli_stmt_get_result($stmt); $product = $res ? mysqli_fetch_assoc($res) : null; mysqli_stmt_close($stmt);
if (!$product) { http_response_code(404); exit('This product is unavailable or out of stock.'); }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name=trim((string)($_POST['customer_name']??'')); $email=trim((string)($_POST['email']??'')); $phone=trim((string)($_POST['contact']??'')); $address=trim((string)($_POST['address']??''));
    $quantity=max(1,(int)($_POST['quantity']??1)); $deliveryDate=trim((string)($_POST['delivery_date']??'')); $deliveryTime=trim((string)($_POST['delivery_time']??'')); $message=trim((string)($_POST['message']??''));
    if ($name==='' || !filter_var($email,FILTER_VALIDATE_EMAIL) || $phone==='' || $address==='' || $deliveryDate==='' || $deliveryTime==='') $error='Please complete all required fields with a valid email.';
    elseif ($deliveryDate < date('Y-m-d')) $error='Please choose a delivery date that is today or later.';
    elseif ($quantity > (int)$product['stock']) $error='Requested quantity exceeds the available stock.';
    else {
        mysqli_begin_transaction($conn);
        $customerId=glycewinGetOrCreateCustomer($conn,$name,$email,$phone,$address);
        $total=(float)$product['price']*$quantity; $payment='QR Code / External Payment'; $status='Pending';
        $ins=$customerId ? mysqli_prepare($conn,'INSERT INTO orders (customer_id,product_id,quantity,total_price,payment_method,delivery_date,delivery_time,message_card,status) VALUES (?,?,?,?,?,?,?,?,?)') : false;
        if ($ins) {
            mysqli_stmt_bind_param($ins,'iiidsssss',$customerId,$productId,$quantity,$total,$payment,$deliveryDate,$deliveryTime,$message,$status);
            if (mysqli_stmt_execute($ins)) {
                $id=(int)mysqli_insert_id($conn); mysqli_commit($conn);
                glycewinRecordTimeline($conn,'product',$id,'Pending','Product order request submitted.');
                glycewinSendEmail($email,'Glycewin product order received',"Hello {$name},\n\nWe received product order #{$id} for {$quantity} × {$product['product_name']}. Total: ₱".number_format($total,2).". Status: Pending.\nPlease use the payment page to submit proof after payment.");
                glycewinNotifyAdmin('New product order request', "Product order #{$id} was submitted by {$name} ({$email}) for {$quantity} × {$product['product_name']}. Total: ₱".number_format($total,2));
                header('Location: order.php?product_id='.$productId.'&success=1&order_id='.$id); exit;
            }
            mysqli_stmt_close($ins);
        }
        mysqli_rollback($conn); $error='We could not save your order. Please check the database upgrade and try again.';
    }
}
$e=static fn($v)=>htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Place Order | Glycewin Handmade Flower Shop</title><link rel="stylesheet" href="css/order.css"><link rel="stylesheet" href="css/feature-upgrade.css"><link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;700&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet"><link rel="stylesheet" href="css/polish.css"></head><body>
<header class="feature-header"><a class="feature-brand" href="index.php"><img src="images/logo.png" alt="Glycewin logo"><span>GLYCEWIN HANDMADE FLOWER SHOP</span></a><nav><a href="index.php">Home</a><a href="products.php">Flowers</a><a href="custom-order.php">Custom</a><a href="bulk-order.php">Bulk</a><a href="inquiry.php">Inquiries</a><a href="tracking.php">Track Order</a></nav></header>
<main class="feature-wrap"><section class="feature-panel"><p class="eyebrow">PRODUCT ORDER REQUEST</p><h1>Order your bouquet</h1><div class="feature-product"><img src="images/products/<?php echo rawurlencode(basename((string)$product['image'])); ?>" alt="<?php echo $e($product['product_name']); ?>"><div><h2><?php echo $e($product['product_name']); ?></h2><p><?php echo $e($product['description']); ?></p><strong>₱<?php echo number_format((float)$product['price'],2); ?></strong><p>Available stock: <?php echo (int)$product['stock']; ?></p></div></div>
<?php if(isset($_GET['success'])): ?><div class="feature-alert success">Order #<?php echo (int)($_GET['order_id']??0); ?> submitted successfully. <a href="payment-proof.php?order_type=product&order_id=<?php echo (int)($_GET['order_id']??0); ?>">Submit payment proof</a> · <a href="tracking.php?order_type=product&order_id=<?php echo (int)($_GET['order_id']??0); ?>">Track order</a></div><?php endif; ?><?php if($error!==''): ?><div class="feature-alert error"><?php echo $e($error); ?></div><?php endif; ?>
<form method="post" class="feature-form"><input type="hidden" name="product_id" value="<?php echo (int)$productId; ?>"><h2>Customer and delivery details</h2><div class="feature-grid"><label>Full name<input name="customer_name" required maxlength="100"></label><label>Email address<input type="email" name="email" required maxlength="100"></label><label>Contact number<input name="contact" required maxlength="20"></label><label>Delivery address<input name="address" required></label><label>Quantity<input type="number" name="quantity" min="1" max="<?php echo (int)$product['stock']; ?>" value="1" required></label><label>Delivery date<input type="date" name="delivery_date" min="<?php echo date('Y-m-d'); ?>" required></label><label>Preferred delivery time<input type="time" name="delivery_time" required></label><label class="full">Message card / order notes<textarea name="message" rows="3" placeholder="Optional card message or special instructions"></textarea></label></div><p class="feature-muted">Payment is made outside this website. The administrator manually reviews the payment proof.</p><button class="feature-button" type="submit">Submit Order Request</button></form></section></main><script src="js/polish.js" defer></script>
</body></html>
