<?php
require_once __DIR__ . "/php/config.php";
$search = trim((string)($_GET['search'] ?? ''));
$category = trim((string)($_GET['category'] ?? ''));
$categories = [];
$catResult = mysqli_query($conn, "SELECT DISTINCT category FROM products WHERE status='Available' AND category<>'' ORDER BY category");
if ($catResult) while ($catRow = mysqli_fetch_assoc($catResult)) $categories[] = (string)$catRow['category'];
if (!in_array($category, $categories, true)) $category = '';
$categoryClause = $category !== '' ? " AND category='" . mysqli_real_escape_string($conn, $category) . "'" : '';
if ($search !== '') {
    $sql = "SELECT * FROM products WHERE status='Available' AND (product_name LIKE ? OR description LIKE ?)" . $categoryClause . " ORDER BY product_id DESC";
    $stmt = mysqli_prepare($conn, $sql); $term = '%' . $search . '%';
    mysqli_stmt_bind_param($stmt, "ss", $term, $term); mysqli_stmt_execute($stmt); $result = mysqli_stmt_get_result($stmt);
} else {
    $result = mysqli_query($conn, "SELECT * FROM products WHERE status='Available'" . $categoryClause . " ORDER BY product_id DESC");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Shop Flowers | Glycewin Handmade Flower Shop</title>

<link rel="stylesheet" href="css/catalog.css">

<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<link rel="stylesheet" href="css/polish.css">
</head>

<body>

<header>

<div class="logo">

<a href="index.php">

<img src="images/logo.png" alt="Logo">

</a>

<span>GLYCEWIN</span>

</div>

<nav>

<a href="index.php">

Home

</a>

<a href="products.php" class="active">

Shop Flowers

</a>

<a href="custom-order.php">

Custom Orders

</a>

<a href="bulk-order.php">

Bulk Orders

</a>

<a href="inquiry.php">Inquiries</a>
<a href="tracking.php">

Track Order

</a>

</nav>

<div class="menu-btn">

☰

</div>

</header>

<!-- ================= HERO ================= -->

<section class="hero">

<div class="hero-overlay">

<h1>

SHOP FLOWERS

</h1>

<p>

Browse our handmade flower arrangements crafted with love and creativity.

</p>

<div class="search-box">

<form method="get" action="products.php" class="catalog-search-form">
<input
 type="search"
 name="search"
 value="<?php echo htmlspecialchars($search, ENT_QUOTES, 'UTF-8'); ?>"
 placeholder="Search handmade flowers..."
 aria-label="Search handmade flowers">
<button type="submit">Search</button>
<?php if ($search !== ''): ?>
<a href="products.php" class="clear-search">Clear</a>
<?php endif; ?>
</form>

</div>

</div>

</section>

<!-- ================= CATALOG ================= -->

<section class="catalog-container">

<div class="sidebar">

<h2>

Categories

</h2>

<ul>
<li class="<?php echo $category === '' ? 'selected' : ''; ?>"><a href="products.php<?php echo $search !== '' ? '?search=' . rawurlencode($search) : ''; ?>">🌸 All Flowers</a></li>
<?php foreach ($categories as $cat): ?>
<li class="<?php echo $category === $cat ? 'selected' : ''; ?>"><a href="products.php?<?php echo http_build_query(array_filter(['category'=>$cat,'search'=>$search], static fn($v)=>$v!=='')); ?>"><?php echo htmlspecialchars($cat, ENT_QUOTES, 'UTF-8'); ?></a></li>
<?php endforeach; ?>
</ul>

</div>

<div class="catalog-content">

<div class="catalog-header">

<h2>

Flower Collection

</h2>

<p>
<?php echo $search !== '' ? 'Search results for: ' . htmlspecialchars($search, ENT_QUOTES, 'UTF-8') : 'Showing Available Handmade Bouquets'; ?><?php echo $category !== '' ? ' · Category: ' . htmlspecialchars($category, ENT_QUOTES, 'UTF-8') : ''; ?>
</p>

</div>

<div class="products-scroll">

<div class="products">

<?php

if(mysqli_num_rows($result) > 0){

    while($row = mysqli_fetch_assoc($result)){

?>

<div class="card">

<img

src="images/products/<?php echo htmlspecialchars($row['image']); ?>"

alt="<?php echo htmlspecialchars($row['product_name']); ?>">

<div class="card-info">

<h3>

<?php echo htmlspecialchars($row['product_name']); ?>

</h3>

<p>

<?php echo htmlspecialchars($row['description']); ?>

</p>

<span class="price">

₱<?php echo number_format($row['price'],2); ?>

</span>

<div class="buttons">

<a href="product-details.php?id=<?php echo $row['product_id']; ?>">

View Details

</a>

<a href="order.php?product_id=<?php echo $row['product_id']; ?>">

Order

</a>

</div>

</div>

</div>

<?php

    }

}else{

?>

<div class="card">

<div class="card-info">

<h3>

No Products Available

</h3>

<p>

There are currently no available handmade flowers.

Please check back later.

</p>

</div>

</div>

<?php

}

?>

</div>

</div>

</div>

</section>

<footer>

<p>

© 2026 Glycewin Handmade Flower Shop

</p>

</footer>

<script src="js/polish.js" defer></script>
</body>

</html>