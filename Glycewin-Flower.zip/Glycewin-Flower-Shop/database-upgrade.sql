-- GLYCEWIN FEATURE UPGRADE MIGRATION
-- IMPORTANT: Back up the entire database before running this file.
-- Run this once in phpMyAdmin against glycewin_flower_shop.
-- Existing tables and records are retained; only supporting columns/tables are added.

-- Add fields needed to preserve bulk-request details while retaining the existing schema.
ALTER TABLE bulk_orders
  ADD COLUMN IF NOT EXISTS location VARCHAR(255) NOT NULL DEFAULT '' AFTER event_date,
  ADD COLUMN IF NOT EXISTS guests INT UNSIGNED NOT NULL DEFAULT 0 AFTER location,
  ADD COLUMN IF NOT EXISTS bouquet_size VARCHAR(100) NOT NULL DEFAULT '' AFTER quantity,
  ADD COLUMN IF NOT EXISTS delivery_time VARCHAR(100) NOT NULL DEFAULT '' AFTER bouquet_size,
  ADD COLUMN IF NOT EXISTS reference_image VARCHAR(255) NOT NULL DEFAULT '' AFTER notes;

-- Administrator-managed production schedule fields for each order type.
ALTER TABLE custom_orders
  ADD COLUMN IF NOT EXISTS production_start_date DATE NULL,
  ADD COLUMN IF NOT EXISTS production_due_date DATE NULL,
  ADD COLUMN IF NOT EXISTS production_notes VARCHAR(500) NOT NULL DEFAULT '';
ALTER TABLE bulk_orders
  ADD COLUMN IF NOT EXISTS production_start_date DATE NULL,
  ADD COLUMN IF NOT EXISTS production_due_date DATE NULL,
  ADD COLUMN IF NOT EXISTS production_notes VARCHAR(500) NOT NULL DEFAULT '';
ALTER TABLE orders
  ADD COLUMN IF NOT EXISTS production_start_date DATE NULL,
  ADD COLUMN IF NOT EXISTS production_due_date DATE NULL,
  ADD COLUMN IF NOT EXISTS production_notes VARCHAR(500) NOT NULL DEFAULT '';

-- Add the requested Shipped workflow without removing the existing statuses.
ALTER TABLE custom_orders
  MODIFY status ENUM('Pending','Confirmed','Preparing','Ready for Delivery','Out for Delivery','Shipped','Completed','Cancelled') NOT NULL DEFAULT 'Pending';
ALTER TABLE bulk_orders
  MODIFY status ENUM('Pending','Confirmed','Preparing','Ready for Delivery','Out for Delivery','Shipped','Completed','Cancelled') NOT NULL DEFAULT 'Pending';
ALTER TABLE orders
  MODIFY status ENUM('Pending','Confirmed','Preparing','Ready for Delivery','Out for Delivery','Shipped','Completed','Cancelled') NOT NULL DEFAULT 'Pending';

CREATE TABLE IF NOT EXISTS inquiries (
  inquiry_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  customer_name VARCHAR(150) NOT NULL,
  email VARCHAR(190) NOT NULL,
  phone VARCHAR(60) NOT NULL DEFAULT '',
  subject VARCHAR(190) NOT NULL,
  message TEXT NOT NULL,
  admin_response TEXT NULL,
  status ENUM('New','In Progress','Responded','Closed') NOT NULL DEFAULT 'New',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  responded_at DATETIME NULL,
  INDEX idx_inquiries_status_created (status, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payment_submissions (
  payment_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  order_type ENUM('custom','bulk','product') NOT NULL,
  order_id INT UNSIGNED NOT NULL,
  payer_name VARCHAR(150) NOT NULL DEFAULT '',
  payer_email VARCHAR(190) NOT NULL,
  reference_number VARCHAR(120) NOT NULL DEFAULT '',
  proof_file VARCHAR(255) NOT NULL,
  verification_status ENUM('Pending','Verified','Rejected') NOT NULL DEFAULT 'Pending',
  admin_note VARCHAR(500) NOT NULL DEFAULT '',
  submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  reviewed_at DATETIME NULL,
  INDEX idx_payment_order (order_type, order_id),
  INDEX idx_payment_status (verification_status, submitted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS order_status_history (
  history_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  order_type ENUM('custom','bulk','product') NOT NULL,
  order_id INT UNSIGNED NOT NULL,
  status VARCHAR(60) NOT NULL,
  note VARCHAR(500) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_order_history (order_type, order_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- If an earlier revision already created the payment table, extend it to support product orders too.
ALTER TABLE payment_submissions MODIFY order_type ENUM('custom','bulk','product') NOT NULL;

-- Ensure the admin password column can hold a modern password_hash() value.
ALTER TABLE admins MODIFY password VARCHAR(255) NOT NULL;
