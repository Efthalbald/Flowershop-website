/* Glycewin – customer side interaction polish.
   Progressive enhancement only: the site works exactly the same without it. */
(function () {
  'use strict';
  var doc = document, root = doc.documentElement;
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  root.classList.add('gw-js');

  function $(s, c) { return (c || doc).querySelector(s); }
  function $$(s, c) { return Array.prototype.slice.call((c || doc).querySelectorAll(s)); }
  function onReady(fn) { if (doc.readyState !== 'loading') fn(); else doc.addEventListener('DOMContentLoaded', fn); }

  onReady(function () {
    /* ---- Sticky header shadow + back-to-top (safe if main.js also exists) ---- */
    var header = $('header');
    var backTop = $('.back-top');
    var ticking = false;
    function onScroll() {
      var y = window.pageYOffset || root.scrollTop;
      if (header) header.classList.toggle('gw-scrolled', y > 40);
      if (backTop) backTop.classList.toggle('show', y > 400);
      ticking = false;
    }
    window.addEventListener('scroll', function () { if (!ticking) { ticking = true; requestAnimationFrame(onScroll); } }, { passive: true });
    onScroll();
    if (backTop) backTop.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' }); });

    /* ---- Mobile menu toggle (home page) ---- */
    var toggle = $('.menu-toggle'), links = $('.nav-links');
    if (toggle && links && !toggle.__gw) {
      toggle.__gw = true;
      toggle.setAttribute('role', 'button'); toggle.setAttribute('tabindex', '0');
      toggle.setAttribute('aria-label', 'Toggle navigation'); toggle.setAttribute('aria-expanded', 'false');
      var setMenu = function (open) {
        links.classList.toggle('active', open); toggle.classList.toggle('open', open);
        toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      };
      toggle.addEventListener('click', function () { setMenu(!links.classList.contains('active')); });
      toggle.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle.click(); } });
      $$('a', links).forEach(function (a) { a.addEventListener('click', function () { setMenu(false); }); });
      doc.addEventListener('keydown', function (e) { if (e.key === 'Escape') setMenu(false); });
    }

    /* ---- Smooth in-page anchors, offset for sticky header ---- */
    $$('a[href^="#"]').forEach(function (a) {
      a.addEventListener('click', function (e) {
        var id = a.getAttribute('href');
        if (id.length < 2) return;
        var t = $(id); if (!t) return;
        e.preventDefault();
        var off = header ? header.offsetHeight : 0;
        window.scrollTo({ top: t.getBoundingClientRect().top + window.pageYOffset - off - 10, behavior: reduce ? 'auto' : 'smooth' });
      });
    });

    /* ---- Scroll reveal ---- */
    var targets = $$([
      '.section-heading', '.category-card', '.featured-card', '.about-grid', '.testimonial-card',
      '.gallery-grid > *', '.custom-box', '.benefit-card', '.intro-card', '.form-card', '.summary-card',
      '.related-card', '.product-card', '.feature-panel', '.products .card'
    ].join(','));
    if (!reduce && 'IntersectionObserver' in window && targets.length) {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (!en.isIntersecting) return;
          var el = en.target; el.classList.add('gw-in'); io.unobserve(el);
          setTimeout(function () { el.classList.add('gw-done'); }, 900);
        });
      }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
      targets.forEach(function (el) {
        // gentle stagger between siblings
        var idx = Array.prototype.indexOf.call(el.parentNode.children, el);
        el.style.setProperty('--gw-delay', Math.min(idx, 5) * 0.07 + 's');
        el.classList.add('gw-reveal');
        io.observe(el);
      });
    }

    /* ---- Submit feedback: spinner + double-click protection ---- */
    $$('form').forEach(function (form) {
      form.addEventListener('submit', function (ev) {
        setTimeout(function () {
          if (form.__gwBusy || ev.defaultPrevented) return;
          var btn = $('button[type="submit"], input[type="submit"], button:not([type])', form);
          if (!btn) return;
          form.__gwBusy = true; btn.classList.add('is-loading');
          setTimeout(function () { form.__gwBusy = false; btn.classList.remove('is-loading'); }, 6000);
        }, 0);
      });
    });
    $$('form').forEach(function (form) {
      form.addEventListener('submit', function (e) { if (form.__gwBusy) e.preventDefault(); }, true);
    });

    /* ---- Order summary values "bump" when they change ---- */
    var watch = $$('#summary_flower,#summary_size,#summary_wrap,#summary_color,#estimated_price,.summary-row.total span:last-child');
    if (window.MutationObserver) {
      watch.forEach(function (el) {
        new MutationObserver(function () { el.classList.remove('gw-bump'); void el.offsetWidth; el.classList.add('gw-bump'); })
          .observe(el, { childList: true, characterData: true, subtree: true });
      });
    }

    /* ---- Upload box drag-over highlight ---- */
    $$('.upload-box').forEach(function (box) {
      ['dragenter', 'dragover'].forEach(function (ev) { box.addEventListener(ev, function () { box.classList.add('is-dragover'); }); });
      ['dragleave', 'drop'].forEach(function (ev) { box.addEventListener(ev, function () { box.classList.remove('is-dragover'); }); });
    });

    /* ---- Product detail: smoother thumbnail swap ---- */
    var main = $('.main-image');
    if (main) {
      $$('.thumbnails img').forEach(function (t) {
        t.addEventListener('click', function () {
          $$('.thumbnails img').forEach(function (x) { x.style.outline = ''; });
          t.style.outline = '2px solid #d46a9a'; t.style.outlineOffset = '2px';
        });
      });
    }
  });
})();

/* ======================================================================
   Feature polish: inquiry message, QR payment proof, email notices
   (front-end only – sending/saving is still done by the existing PHP)
   ====================================================================== */
(function () {
  'use strict';
  var doc = document;
  function $(s, c) { return (c || doc).querySelector(s); }
  function $$(s, c) { return Array.prototype.slice.call((c || doc).querySelectorAll(s)); }
  function store(op, k, v) { try { if (op === 'get') return sessionStorage.getItem(k); if (op === 'set') sessionStorage.setItem(k, v); else sessionStorage.removeItem(k); } catch (e) {} return null; }
  function note(text, cls) { var d = doc.createElement('div'); d.className = 'gw-note ' + (cls || ''); d.innerHTML = text; return d; }
  function esc(t) { return String(t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function size(b) { return b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB'; }

  function ready() {
    var success = $('.feature-alert.success');
    if (success) {
      success.setAttribute('role', 'status');
      success.innerHTML = '<span class="gw-check" aria-hidden="true">✓</span><span>' + success.innerHTML + '</span>';
      success.classList.add('gw-success-pop');
      setTimeout(function () { success.scrollIntoView({ behavior: 'smooth', block: 'center' }); }, 250);
    }
    var err = $('.feature-alert.error'); if (err) err.setAttribute('role', 'alert');

    /* ---------- Inquiry form ---------- */
    var msg = $('textarea[name="message"]'), subj = $('input[name="subject"]');
    var form = msg && msg.form;
    if (form && subj) {
      var email = $('input[name="email"]', form);
      var max = parseInt(msg.getAttribute('maxlength'), 10) || 5000;
      var counter = doc.createElement('small'); counter.className = 'gw-counter'; msg.parentNode.appendChild(counter);
      var upd = function () {
        var n = msg.value.length; counter.textContent = n + ' / ' + max;
        counter.classList.toggle('warn', n > max * 0.9);
        msg.style.height = 'auto'; msg.style.height = Math.min(msg.scrollHeight + 2, 420) + 'px';
      };
      msg.addEventListener('input', upd);

      var mail = note('', 'gw-note-mail'); form.insertBefore(mail, $('button[type="submit"]', form));
      var showMail = function () {
        var v = email ? email.value.trim() : '';
        var ok = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
        mail.innerHTML = '<span class="gw-ico">✉</span><span>' + (ok
          ? 'A confirmation email will be sent to <strong>' + esc(v) + '</strong>, and the shop will reply to this address.'
          : 'Enter your email address – a confirmation and the shop\'s reply will be sent there.') + '</span>';
        if (email) email.classList.toggle('gw-invalid', v !== '' && !ok);
      };
      if (email) email.addEventListener('input', showMail);

      /* draft autosave (cleared after a successful send) */
      var KEY = 'gw-inquiry-draft', fields = $$('input:not([type=hidden]),textarea', form);
      if (success) store('del', KEY);
      else {
        try {
          var d = JSON.parse(store('get', KEY) || 'null');
          if (d) fields.forEach(function (f) { if (!f.value && d[f.name]) f.value = d[f.name]; });
        } catch (e) {}
        fields.forEach(function (f) {
          f.addEventListener('input', function () {
            var o = {}; fields.forEach(function (x) { o[x.name] = x.value; }); store('set', KEY, JSON.stringify(o));
          });
        });
      }
      upd(); showMail();
    }

    /* ---------- QR payment proof ---------- */
    var qr = $('.payment-qr');
    if (qr) {
      var wrap = doc.createElement('div'); wrap.className = 'gw-qr-actions';
      wrap.innerHTML = '<button type="button" class="gw-chip" data-z>🔍 Enlarge QR</button><a class="gw-chip" download="glycewin-payment-qr.png" href="' + esc(qr.getAttribute('src')) + '">⬇ Save QR</a>';
      qr.parentNode.insertBefore(wrap, qr.nextSibling);
      qr.classList.add('gw-zoomable'); qr.tabIndex = 0;
      var open = function () {
        var o = doc.createElement('div'); o.className = 'gw-lightbox'; o.setAttribute('role', 'dialog'); o.setAttribute('aria-label', 'Payment QR code');
        o.innerHTML = '<img src="' + esc(qr.getAttribute('src')) + '" alt="Shop payment QR code"><button type="button" aria-label="Close">✕</button>';
        var close = function () { o.classList.remove('in'); setTimeout(function () { o.remove(); }, 250); doc.removeEventListener('keydown', esc2); };
        var esc2 = function (e) { if (e.key === 'Escape') close(); };
        o.addEventListener('click', close); doc.addEventListener('keydown', esc2);
        doc.body.appendChild(o); requestAnimationFrame(function () { o.classList.add('in'); });
      };
      qr.addEventListener('click', open); qr.addEventListener('keydown', function (e) { if (e.key === 'Enter') open(); });
      $('[data-z]', wrap).addEventListener('click', open);
    }

    var file = $('input[type="file"][name="proof_file"]');
    if (file) {
      var box = doc.createElement('div'); box.className = 'gw-preview'; box.hidden = true; file.parentNode.appendChild(box);
      var pform = file.form, pemail = $('input[name="payer_email"]', pform);
      var okTypes = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'], lastURL = null;
      file.addEventListener('change', function () {
        if (lastURL) { URL.revokeObjectURL(lastURL); lastURL = null; }
        var f = file.files && file.files[0];
        if (!f) { box.hidden = true; return; }
        var bad = okTypes.indexOf(f.type) < 0 ? 'Use a JPG, PNG, WEBP or PDF file.' : (f.size > 5242880 ? 'This file is ' + size(f.size) + ' – the limit is 5 MB.' : '');
        if (bad) { file.value = ''; box.hidden = false; box.className = 'gw-preview bad'; box.innerHTML = '<span class="gw-ico">⚠</span><div><strong>' + bad + '</strong></div>'; return; }
        box.hidden = false; box.className = 'gw-preview good';
        var thumb;
        if (f.type === 'application/pdf') thumb = '<span class="gw-pdf">PDF</span>';
        else { lastURL = URL.createObjectURL(f); thumb = '<img alt="Preview of selected proof" src="' + lastURL + '">'; }
        box.innerHTML = thumb + '<div><strong>' + esc(f.name) + '</strong><small>' + size(f.size) + ' · ready to submit</small></div>';
      });
      var pmail = note('', 'gw-note-mail'); pform.insertBefore(pmail, $('button[type="submit"]', pform));
      var showP = function () {
        var v = pemail ? pemail.value.trim() : '';
        var ok = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
        pmail.innerHTML = '<span class="gw-ico">✉</span><span>' + (ok
          ? 'We will email <strong>' + esc(v) + '</strong> when your proof is received and again when the shop verifies or rejects it.'
          : 'You will be emailed when your proof is received and when it is verified or rejected.') + '</span>';
        if (pemail) pemail.classList.toggle('gw-invalid', v !== '' && !ok);
      };
      if (pemail) pemail.addEventListener('input', showP);
      showP();
    }
  }
  if (doc.readyState !== 'loading') ready(); else doc.addEventListener('DOMContentLoaded', ready);
})();


/* ======================================================================
   Glycewin interaction upgrade – subtle, fast, non-blocking enhancements
   ====================================================================== */
(function () {
  'use strict';

  var doc = document;
  var reduce = window.matchMedia &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function $(s, c) { return (c || doc).querySelector(s); }
  function $$(s, c) { return Array.prototype.slice.call((c || doc).querySelectorAll(s)); }

  function ready(fn) {
    if (doc.readyState !== 'loading') fn();
    else doc.addEventListener('DOMContentLoaded', fn);
  }

  ready(function () {
    /* Header state: adds a little depth after the user starts scrolling. */
    var header = $('.feature-header');
    if (header) {
      var ticking = false;
      function updateHeader() {
        var y = window.pageYOffset || doc.documentElement.scrollTop || 0;
        header.classList.toggle('gw-scrolled', y > 18);
        ticking = false;
      }
      window.addEventListener('scroll', function () {
        if (!ticking) {
          ticking = true;
          window.requestAnimationFrame(updateHeader);
        }
      }, { passive: true });
      updateHeader();
    }

    /* Ripple-like click feedback for primary actions. */
    $$('.feature-button, .btn').forEach(function (button) {
      button.addEventListener('click', function (e) {
        if (reduce) return;
        var rect = button.getBoundingClientRect();
        var dot = doc.createElement('span');
        dot.className = 'gw-ripple';
        dot.style.left = (e.clientX - rect.left) + 'px';
        dot.style.top = (e.clientY - rect.top) + 'px';
        button.appendChild(dot);
        window.setTimeout(function () {
          if (dot.parentNode) dot.parentNode.removeChild(dot);
        }, 550);
      });
    });

    /* Make inquiry/tracking result blocks feel intentional when present. */
    var result = $('.order-result');
    if (result && !reduce) {
      result.classList.add('gw-result-ready');
    }

    /* Gentle hover tilt only on larger screens and only for the main panel. */
    if (!reduce && window.matchMedia && window.matchMedia('(hover:hover)').matches) {
      var panel = $('.feature-panel');
      if (panel) {
        panel.addEventListener('pointermove', function (e) {
          if (window.innerWidth < 900) return;
          var r = panel.getBoundingClientRect();
          var x = (e.clientX - r.left) / r.width - .5;
          var y = (e.clientY - r.top) / r.height - .5;
          panel.style.transform =
            'perspective(1200px) rotateX(' + (-y * 0.55).toFixed(2) +
            'deg) rotateY(' + (x * 0.55).toFixed(2) + 'deg)';
        });
        panel.addEventListener('pointerleave', function () {
          panel.style.transform = '';
        });
      }
    }

    /* Auto-scroll to the submitted inquiry response so it is immediately visible. */
    var success = $('.feature-alert.success');
    var error = $('.feature-alert.error');
    if ((success || error) && window.location.hash === '#message') {
      var target = success || error;
      window.setTimeout(function () {
        target.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'center' });
      }, 100);
    }
  });
})();
